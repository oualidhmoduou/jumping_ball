const container=document.querySelector('#container')
const score=document.querySelector('#score')
const barre=document.querySelector('#barre')
const ball=document.querySelector('#ball')
const go=document.querySelector('#go')
go.style.display="none";
let sco=1;
let rx=0;
let bx=0;
let by=0;

function movebarre(e) {
    if(e.key=="ArrowRight"){
        rx+=10;
        barre.style.left = rx + "px";
    } 
    if(e.key=="ArrowLeft"){
        rx-=10;
        barre.style.left = rx + "px";
    } 
}
function rand_loc() {
    let x=Math.random() * 600;
    return x;
}
bx=rand_loc();

document.addEventListener('keydown',movebarre)
document.addEventListener('keydown',setInterval(ball_move,100))
function ball_move() {
    by+=10;
    ball.style.top=by + "px" ;
    ball.style.left=bx + "px";
    if(ball.style.top=="700px"){
        go.style.display="block";
        ball.style.display="none";
        score.style.display="none";
        barre.style.display="none";
    }
    else if(ball.style.top=="620px" && bx<(rx+150)&& bx>(rx-150) ){
        ball.style.top=0 + "px" ;
        score.textContent=sco;
        sco++;
        by=0;
        bx=rand_loc();
    }
}
